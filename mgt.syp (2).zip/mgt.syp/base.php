<?php
$mysqli = mysqli_connect('localhost', 'root', '', 'mgt'); 
mysqli_query($mysqli, "SET NAMES utf8");
?>
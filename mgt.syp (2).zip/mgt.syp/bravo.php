<!DOCTYPE html>
<html>
    <head>
        <title>merci pour votre commznde</title>
        <link rel="stylesheet" href="css/bravo.css" />
    </head>
    <body>
        <p>commande reussie !!!!      &emsp; <a href="/mgt.syp/index.php">X</a></p>
        <?php 
        header ("Refresh: 3;URL=/mgt.syp/index.php");
        // Redirection vers page_suivante.php après un délai de 5 secondes
        // durant lesquelles la page actuelle (page_premiere.php, par exemple) est affichée
        ?>
    </body>
</html>
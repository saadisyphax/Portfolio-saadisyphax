<?php

session_start();
require_once "base.php";
?>
<html>

<head>
  <?php
  if (isset($_SESSION["ID"]) == false) {
    header("Location:index.php");
  }
  ?>
  <link rel="stylesheet" href="css/bon_de_commande.css" />
  <link rel="stylesheet" href="css/style.css" />

  <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
  <?php
  if (isset($_SESSION["ID"]) == true) {
    require_once("header1.php");
  } else {
    require_once("header.php");
  }



  ?>
  <?php
  $iduser = $_GET["iduser"];
  $idsympa = $_GET["idsympa"];
  ?>





</head>

<body>
  <?php
  $sql = "select * from panier where id_user = " . $iduser;
  $result = mysqli_query($mysqli, $sql);
  $row = mysqli_fetch_all($result,MYSQLI_ASSOC) ;
   $total=0;
?>
  
    
  <?php 

 

 
  $sqluser = "select * from utilisateur where ID_user = " . $iduser;
  $resultuser = mysqli_query($mysqli, $sqluser);


  while ($rowuser = mysqli_fetch_array($resultuser)) {
    $nomuser = $rowuser["nom"];
    $prenomuser = $rowuser["prenom"];
    $lemail = $rowuser["mail"];
    $tel = $rowuser["telephone"];
    
  }

  ?>

  <div class="bon">
    <p class="titre">Bon de commande</p>
    <hr>
    <div class="d">
      <div>
        <p class="a">MGT SHOP</p>
        <p class="b">17 rue linée </br>Paris 75005</br>07.51.96.44.83</p>
      </div>
      <div class="c">
        <p>date:<?php $date = date('d-m-y h:i:s');echo $date; ?> </p>
        <p>destinatire: Mr <?php echo $nomuser ?> </p>
        <p>Adresse mail :<?php echo $lemail ?> </p>       
      </div>
    </div>
    <div class="les_produits">
    <table>
   <tr>
       <th colspan='0'>nom du produit</th>
       
       <th colspan='0'>Quantité</th>
       <th colspan='0'>Prix</th>
       <th colspan='0'>total</th>
   </tr>

<?php
   foreach($row as $commande ){
    $sqltel = "select * from telephone where id_tel =" . $commande['id_tel'];
    $resulttel = mysqli_query($mysqli, $sqltel);
    $row_tel=mysqli_fetch_array($resulttel);
  ?>
 
   <tr>
   <td><?php echo $row_tel['nom']?></td>
   <td><?php echo $commande['quantite']?>Piéce</td>
   <td><?php echo $row_tel['prix']?>$</td>
   
   <?php
   $totalequantite=$row_tel['prix']* $commande['quantite'];
   $total+=$totalequantite;?>
   <td><?php echo $totalequantite?>$</td>
   </tr><?php
    } ?>
  
   </table>
   <hr>
   Prix a payer :<?php echo  $total ?>$
       </div>
  </div>
  <button onclick="window.location.href = '/mgt.syp/bravo.php';">Confirmer la commande</button>
</body>
<?php
  require_once("footer.php");
  ?>
</html>
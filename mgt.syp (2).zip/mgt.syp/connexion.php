<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf8" />
    <title>mgt.syp</title>
    
    <link rel="stylesheet" href="css/connexion.css" />
    <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
    
  </head>
  <body>
    <form method="get" action="traitement connexion.php">
      <h1>S𝒆 𝒄𝒐𝒏𝒏𝒆𝒄𝒕𝒆𝒓</h1>
     
      <p class="chose-email">veuillez insérez vos identifiants:</p>
      <div class="inputs">
        <input type="email" placeholder="email" name="lemail">
        <input type="password" placeholder="mot de passe" name="mdp">

      </div>
      <p class="inscription">je n'ai pas de compte.<span><a href='/mgt.syp/inscription.php'>je m'inscrit</a></span> .</p>
      <div align="center">
        <button type="submit">se connecter</button>
      </div>
    </form>
  </body>
</html>
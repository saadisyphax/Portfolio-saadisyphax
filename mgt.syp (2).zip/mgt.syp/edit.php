<?php
session_start();
require_once "base.php";
?>

<!DOCTYPE html>
<html>

  <head>
    <title>Edition</title>
    <meta charset="utf8"/>
  </head>

  <body>
        <?php
        $id = $_GET["id"];
        $sql =  "SELECT * FROM utilisateur WHERE ID_user = " . $id;
        $result = mysqli_query($mysqli, $sql);
        $row = mysqli_fetch_array($result);
         ?> 

    <form action ="traitedit.php" method = "GET" >
     
        <p>
            Prénom : <input type="text" name="prenom" value="<?php echo $row["prenom"] ?>" />
        </p>
        <p>
            Nom de famille : <input type="text" name="NomFamille" value="<?php echo $row["nom"] ?>" />
        </p>
        <p>
            Adresse mail : <input type="text" name="Adresse" value="<?php echo $row["mail"] ?>" />
        </p>
        <p>
            Numéro de téléphone : <input type="text" name="tel" value="<?php echo $row["telephone"] ?>" />
        </p>
        <p>
            Mot de passe : <input type="password" name="motdp" value="<?php echo $row["mdp"] ?>" />
        </p>
        <p>
            <input type="submit" value = "Modifier" />
        </p>
    </form>

  </body>
  

</html>

<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf8" />
    <title>mgt.syp</title>
    <link rel="stylesheet" href="css/footer.css" />
    <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
  
  </head>
  <body>
  <footer>
    <p>&copy; Contactez-nous au 07 51 96 44 83</p>
    <div class="social-media">
      <p><i class="fab fa-facebook-f"></i></p>
      <p><i class="fab fa-twitter"></i></p>
      <p><i class="fab fa-instagram"></i></p>
      <p><i class="fab fa-linkedin-in"></i></p>
    </div>
  </footer>
</body>
</html>
<!DOCTYPE html>
<html>
<html>

<head>
  <meta charset="utf8" />
  <title><i class="fa-solid fa-mobile-notch"></i>mgt.shop</title>
  <link rel="stylesheet" href="css/style1.css" />
  <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>

</head>

<body>
  <nav>
    <p>𝒎𝒈𝒕.𝒔𝒚𝒑𝒉𝒂𝒙</p>
    <div>
      <form>
        <input type="search" placeholder="Rechercher" />

      </form>
      <p><a href="/mgt.syp/connexion.php">Connectez-vous</a></p>
      <p><a href="/mgt.syp/inscription.php">inscription</a></p>
      <p><a href="/mgt.syp/index.php">Page d'accueil</a></p>


      <p><a href="/mgt.syp/connexion.php"><i class="fa-solid fa-cart-shopping"></i></a></p>



    </div>
  </nav>
</body>

</html>
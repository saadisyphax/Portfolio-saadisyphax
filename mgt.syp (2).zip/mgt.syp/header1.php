<?php
      $id = $_SESSION["ID"];
      ?>

    <nav>
        <bav class="logo"><p>MGT.SHOP</p></bav> 
        <div class="body">
            <form action="barederecherche.php" method="GET">
                <input type="search" name="q" placeholder="Rechercher" />
            </form>
            <div ><a href="/mgt.syp/index.php">Page d'accueil</a></div>
            <div><a href="">historique de commandes</a></div>

            <div>
                <a href="/mgt.syp/panier.php"><i class="fa-solid fa-cart-shopping"></i
      ></a>
            </div>
            <div>
                <li class="services">
                    <a href="#" title=""><i class="fa-solid fa-user"></i></a>
                    <ul class="sous-menu">
                        <li>
                            <a href="/mgt.syp/profile.php?id=<?php echo $id ?> ">
              Mon profile</a
            >
          </li>
          <li><a href="logout.php" title="">Se déconnecter</a></li>
                    </ul>
                </li>
            </div>
        </div>
    </nav>
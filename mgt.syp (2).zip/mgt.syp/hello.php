<?php
session_start();
require_once "base.php";
?>
<?php
      $nquan = $_GET["qte"];
      $idsympa = $_GET["idsympa"];
      ?>

<?php


$sql = "UPDATE panier SET quantite= " . $nquan . " WHERE ID="  .  $idsympa;



mysqli_query($mysqli, $sql);

header("Location: /mgt.syp/panier.php");

?>
<?php
session_start();
require_once "base.php";
?>

    <!DOCTYPE html>
    <html>
   

    <head>
        <meta charset="utf8" />
        <title>mgt.syp</title>
        <link rel="stylesheet" href="css/index.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/style1.css" />
        <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>

    </head>

    <body>
        <?php
      if (isset($_SESSION["ID"]) == true)
      {   
          require_once("header1.php");
      }
      else
      {        
        require_once("header.php");
      }



    ?>


            <section class="main">
                <div class="winiw">
                    <h1>MGT shop vous souhaite le bienvenue!!</h1>
                    <span style='font-size:50px;'>&#9996;</span>
                </div>
                <!-- Toutes les cartes -->

                <?php
          $sql = "select id_tel,  Nom, Prix, image, ram,stockage, date_de_livraison from telephone";
            $result = mysqli_query($mysqli, $sql);

            echo "<div class='cards' >";

            while ($row = mysqli_fetch_array($result)) {
                $image = $row["image"];
                $nom = $row["Nom"];
                $id = $row["id_tel"];
                $ram= $row["ram"];
                $stockage= $row["stockage"];
                $date_de_livraison= $row["date_de_livraison"];

                echo "<div class='card' >
                    
                    
                    <div>
                    <a   href='produit.php?id=".$id."'>
                      <div style=' text-align: center'>
                          <img  src='img/". $image . "'  height='170px' width='200px'>
                      </div>
                      </a>
                        <div class='card-body'>
                        <a   href='produit.php?id=".$id."'>
                           <div class='nom'>".Strtoupper($row["Nom"])."</div>
                            <div class='prix'>".$row["Prix"]."$</div></a>
                            <div class='ram'>ram:".$ram."</div>
                            <div class='stockage'>stockage:".$row["stockage"]."</div>
                            <div class='date de livraison'>livraison:".$row["date_de_livraison"]."</div>
                          
                        </div>
                    </div>
                    
                    
                    </div>          
                ";
    
            }
            echo "</div>";
            ?>



                    <?php
  require_once("footer.php");
  ?>

    </body>

    </html>
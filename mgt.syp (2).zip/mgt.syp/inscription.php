<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf8" />
    <title>mgt.syp</title>
    <link rel="stylesheet" href="css/inscription.css" />
    <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
    <script src="js/confmdp.js" ></script>
  </head>
  
  <body>
   
    <form action="traitement_inscription.php" method="GET"  onsubmit = "return validate();" >
      <h1>S'INSCRIRE &emsp; <a href="/mgt.syp/index.php">X</a></h1>
     
      <p class="chose-email">veuillez insérez vos information:</p>
      <div class="inputs">
        <input type="text" placeholder="nom" name="lenom">
        <input type="text" placeholder="prénom" name="leprenom">
        <input type="email" placeholder="email" name="lemail">
        <input type="password" placeholder="mot de passe" name="mdp" id="mdp">
        <div id ="messpwd" style="position:relative;top:-10px;left:10px;color:red; font-weight:400;font-size:small; display:none">Ces mots de passe ne correspondent pas</div>
        <input type="password" placeholder="confirmer le mot de passe" name="cmdp" id="cmdp" >
        <div id ="mess" style="position:relative;top:-10px;left:10px;color:red; font-weight:400;font-size:small; display:none">mot de passe faible</div>
        <input type="text" placeholder="numéro de télephonne" name="telf">


      </div>
      <div align="center">
        <button type="submit">s'inscrire</button>
      </div>
    </form>
  </body>
</html>
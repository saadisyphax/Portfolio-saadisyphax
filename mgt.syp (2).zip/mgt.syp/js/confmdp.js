function validate() {


    var res = true;
    //verification mdp
   
    var str = document.getElementById("mdp").value; 
    if (str.match( /[0-9]/g) && 
            str.match( /[A-Z]/g) && 
            str.match(/[a-z]/g) && 
            str.match( /[^a-zA-Z\d]/g) &&
            str.length >= 10) 
       res = true; 
    else 
    document.getElementById("mess").style.display = "inline" ;
    res=false;

    
    // verification nom
    var lenom = document.getElementsByName("lenom")[0].value;
    if (lenom.length < 8)
    {
        alert("nom trop court");
        res = false;
    }

    // verification mdp
    var a = document.getElementById("mdp").value;
    var b = document.getElementById("cmdp").value;

    if (a != b) {
        
        document.getElementById("mdp").style.border = "2px red solid";
        document.getElementById("messpwd").style.display = "inline" ;
        document.getElementById("cmdp").style.border = "2px red solid";
        
        res = false;
    }
    
    return res;

}


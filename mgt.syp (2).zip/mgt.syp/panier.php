<?php
require_once "base.php";
session_start();

if (isset($_SESSION["ID"]) == false) {
  header("Location:index.php");
}

$id = $_SESSION["ID"];

?>
<html>

<head>
  <link rel="stylesheet" href="css/panier.css" />
  <link rel="stylesheet" href="css/style.css" />

  <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
  <?php
  if (isset($_SESSION["ID"]) == true) {
    require_once("header1.php");
  } else {
    require_once("header.php");
  }



  ?>

</head>

<body>
  <main>
    <?php
    $sql = "select * from panier where id_user = " . $id;
    $result = mysqli_query($mysqli, $sql);
    while ($row = mysqli_fetch_array($result)) {
      $id_p = $row["id_tel"];
      $quant = $row["quantite"];

      $theID = $row["ID"];

      $sqltel = "select * from telephone where id_tel =" . $id_p;
      $resulttel = mysqli_query($mysqli, $sqltel);

      while ($rowtel = mysqli_fetch_array($resulttel)) {
        $nomtel = $rowtel["nom"];
        $prixtel = $rowtel["prix"];
        $imagetel = $rowtel["image"];

        echo "<div class='panier' >
      <form class='azul' action='hello.php' method='GET'>
      <img  src='img/" . $imagetel . "'  height='80px' width='80px' name='image'>
      <p class='nom'> Produit:</br> $nomtel </p>
      <p> Quantité : $quant </p>
      <p> Prix : $prixtel € </p>
     <div>
       <select name='qte'> 
      <option value='1'>1</option>
      <option value='2'>2</option>
      <option value='3'>3</option>
      <option value='4'>4</option>
      <option value='5'>5</option>
    </select>
    <button type='submit'>Modifier</button>
    </div>
    <input type='hidden' name='idsympa' value = $theID />
    </form> 
    <form class='hello' action='trairdeletepan.php' method='GET'>

      <button type='submit'>suprimer</button>
      <input type='hidden' name='idsympa' value = $theID />
      </form>
   </div>
    
                     ";
      }
    }
   

    ?>
    <?php
if (isset($id_p) == true)
{
  ?>

<form class="hhhh" action="commander.php" method="GET">

  <button type="submit">Commander et payer  &#129297;</button>
 
  <input type="hidden" name="iduser" value = <?php echo $id ?> />
  <input type="hidden" name="idsympa" value = <?php echo $id_p ?> />
  </form>

  
<?php
}
?>
    <?php
    require_once("footer.php");
    ?>
  </main>
</body>

</html>
<?php
require_once "base.php";
session_start();
  ?>
<html>

<head>
  <link rel="stylesheet" href="css/produit.css" />
  <link rel="stylesheet" href="css/style.css" />

  <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
  <?php
      if (isset($_SESSION["ID"]) == true)
      {   
          require_once("header1.php");
      }
      else
      {        
        require_once("header.php");
      }



    ?>

</head>



<body>

  <section class="main">

    <?php
  $sql = "SELECT t.nom as telnom, t.description as teldesc, t.prix as telprix, t.ram as tram, t.stockage as tstock, t.image as telima, 
  t.date_de_livraison as teldat , m.nom as marquenom, c.NOM as coulnom
  FROM telephone t join marque m ON t.ID_mark = m.ID_mark
  join couleur c on c.ID_COUL = t.ID_couleur
  where t.id_tel =  " . $_GET["id"];




  $result = mysqli_query($mysqli, $sql);

  
  echo "<div class='page_produit' >";
  while ($row = mysqli_fetch_array($result)){
          $nom = $row["telnom"];
          $prix= $row["telprix"];
          $dliv=$row["teldat"];
          $image = $row["telima"];
          $ram= $row["tram"];
          $desc= $row["teldesc"];
          $mark=$row["marquenom"];
          $couleur=$row["coulnom"];
          $stock=$row["tstock"];
          echo "
          <div class='page_body'>
          <div class='image'>            
           <img  src='img/". $image . "'  height='500px' width='500px' name='image'>
          </div>
          <div class='information'>
           <div> ".$nom."</div>
           <hr>
           <div>Marque:".$mark."</div>
           <hr>
           <div>Prix: ".$prix."€</div>
           <hr>
           <div>Couleur:".$couleur."</div>
           <hr>
           <div>Ram:".$ram."</div>
           <hr>
           <div>Capacité	:".$stock."GB</div>
           <hr>
           <div>Description :</br> ".$desc."</div>
           
          </div>
         
          </div> ";
        }
          ?>
<?php
if (isset($_SESSION["ID"]) == true)
{
  ?>



    <form action="traitepanier.php" method="GET">
      Quantité <select name="qte">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
      </select>
      <p>
        <input type="hidden" name="idprod" value="<?php echo $_GET['id'] ?>" />
      </p>
      <p>
        <input type="hidden" name=iduser value="<?php echo $_SESSION["ID"] ?> "
      </p>
      <p>
        <button type="submit">Ajouter au panier</button>
      </p>

    </form>
<?php
}
?>
    </div>


    </div>






    <?php
  require_once("footer.php");
  ?>

</body>

</html>
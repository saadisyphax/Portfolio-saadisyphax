<?php
require_once "base.php";
session_start();
?>

<html>

<head>
  <meta charset="utf8" />
  <title>Profile</title>
  <link rel="stylesheet" href="css/profile.css" />
  <link rel="stylesheet" href="css/style.css" />
  <script src="https://kit.fontawesome.com/db2bf29261.js" crossorigin="anonymous"></script>
  <script>
    function mammouth() {
      document.getElementById('quoi').style.display = 'block';
     
    }
  </script>
  <?php
  if (isset($_SESSION["ID"]) == false) {
    header("Location:index.php");
  }
  ?>
</head>

<body>

  <?php
  require_once("header1.php");
?>

  <?php
$sql = "SELECT * FROM utilisateur WHERE ID_user =  "  . $_GET["id"];


$result = mysqli_query($mysqli, $sql);


  echo "<div class='page_produit' >";
  $row = mysqli_fetch_array($result);
  $nom = $row["nom"];
  $prenom = $row["prenom"];
  $mdp = $row["mdp"];
  $lemail = $row["mail"];
  $tel = $row["telephone"];

  ?>

  <div id="oui" class='info' style="display: block;">

    <div> Nom: <?php echo $nom ?> </div>
    <div> Prenom: <?php echo $prenom ?>           </div>
    <div> Mot de passe:*********</div>
    <div> Adresse mail:<?php echo $lemail ?></div>
    <div> Numéro de téléphone:<?php echo $tel?></div>



    <div class='button'>
      <button onclick="mammouth()" >Editer</button></br>

    </div>
  </div>

  <div 
   id="quoi" style="display: none;">
   
    <hr />
    <hr />
    <form action="traitedit.php" method="GET">
      <p>
        Prénom : <input type="text" name="prenom"  />
      </p>
      <p>
        Nom de famille : <input type="text" name="NomFamille" />
      </p>
      <p>
        Adresse mail : <input type="text" name="Adresse"  />
      </p>
      <p>
        Numéro de téléphone : <input type="text" name="tel" />
      </p>
      <p>
        Mot de passe : <input type="password" name="motdp"  />
      </p>
      <p>
        <input type="submit" value="Modifier" />
      </p>
    </form>

  </div>


</body>

</html>
<?php
session_start();
require_once "base.php";

?>


<?php
    $id11 = $_GET["id11"];
  
    
    $sql = "delete from panier where ID_user = " . $id11;



     mysqli_query($mysqli, $sql);

     header("Location:panier.php");
     
     ?>

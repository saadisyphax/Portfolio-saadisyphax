<?php
session_start();
require_once "base.php";

?>


<?php
    $idpr = $_GET["idsympa"];
  
    
    $sql = "delete from panier where ID = " . $idpr;



     mysqli_query($mysqli, $sql);

     header("Location:panier.php");
     
     ?>

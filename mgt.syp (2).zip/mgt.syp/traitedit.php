<?php
session_start();
require_once "base.php";
?>
<?php
      $id = $_SESSION["ID"];
      ?>

<?php


$sql = "UPDATE utilisateur SET Prenom='" . $_GET["prenom"] . "', nom='" . $_GET["NomFamille"] .
"', mail='" . $_GET["Adresse"] . "', telephone='" . $_GET["tel"] . "', mdp='" . $_GET["motdp"] .
"' WHERE ID_user="  .  $id;




mysqli_query($mysqli, $sql);

header("Location: /mgt.syp/index.php");

?>
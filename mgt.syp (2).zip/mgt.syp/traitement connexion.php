
<?php
session_start();
require_once "base.php";
?>
<!DOCTYPE html>
<html>

  <head>
    <title>Traitement</title>
    <meta charset="utf8"/>
  </head>

  <body>
    <?php



     $lemail = $_GET["lemail"];
     $password = $_GET["mdp"];

     $lemail = addslashes($lemail);
     $password = addslashes($password);

    $sql = "select count(*) as nb, ID_user, mdp from utilisateur where mail ='" . $lemail . "'";
       
        $result = mysqli_query($mysqli, $sql);
        $row = mysqli_fetch_array($result);
        $resultat = $row["nb"];
    
        if ($resultat > 0) {
            $passhash = $row["mdp"];

            if (password_verify($password, $passhash) == true)
            { 
              $_SESSION["ID"] = $row["ID_user"];
              header("Location:index.php");
            }
            else
            { 
              echo ("<h1>Identifiants incorects</h1>");  
              
            }

          }
            
            
            
    
       
    
    
    ?>
    

 
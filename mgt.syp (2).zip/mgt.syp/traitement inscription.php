<?php
session_start();
require_once "base.php";

?>


<?php
    $nom = $_GET["lenom"];
    $pwd = $_GET["mdp"];
    $prenom = $_GET["leprenom"];
    $tlf= $_GET["telf"];
    
    $sql = "insert into utilisateur " . 
     "values(null, '" . $nom . "','" . $prenom . "','" . $pwd . 
     "','" . $tlf .  "','" . $lemail . "')";



     mysqli_query($mysqli, $sql);

     header("Location:index.php");
     
     ?>

<?php
session_start();
require_once "base.php";

?>


<?php
    $nom = $_GET["lenom"];
    $pwd = $_GET["mdp"];
    $lemail = $_GET["lemail"];

    $hashpwd = password_hash($pwd, PASSWORD_DEFAULT);

    $prenom = $_GET["leprenom"];
    $tlf= $_GET["telf"];
    
    $sql = "insert into utilisateur " . 
     "values(null, '" . $nom . "','" . $prenom . "','" . $hashpwd . 
     "','" . $tlf .  "','" . $lemail . "')";
    
     mysqli_query($mysqli, $sql);

     header("Location:index.php");
     
     ?>

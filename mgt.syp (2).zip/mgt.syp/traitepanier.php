<?php
require_once "base.php";
session_start();

if (isset($_SESSION["ID"]) == false)
{
  header("Location:index.php");
}

$id = $_SESSION["ID"];

?>

<?php



    $iduser = $_GET["iduser"];
    $idprod = $_GET["idprod"];   
    $qte = $_GET["qte"]; 

    $sql = "insert into panier value(null, $iduser, $qte, $idprod)";




    mysqli_query($mysqli, $sql);

    
     header("Location:index.php");


?>